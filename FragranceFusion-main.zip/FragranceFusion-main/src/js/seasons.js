function redirectTo(page) {
    window.location.href = page;
}
function redirectTo(path) {
    window.location.href = path;
}